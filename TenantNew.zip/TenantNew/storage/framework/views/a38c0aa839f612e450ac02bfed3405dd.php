

<?php $__env->startSection('title', 'My Requests'); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="card-header bg-light d-flex justify-content-between align-items-center">
        <span class="fw-bold">Maintenance Requests</span>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#createRequestModal">
            + Create Request
        </button>
    </div>

    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if($requests->isEmpty()): ?>
            <div class="text-center py-4 text-muted">
                <i class="bi bi-exclamation-circle fs-1 mb-2"></i>
                <p class="mb-0">No maintenance requests found. Click <strong>"Create Request"</strong> to add one.</p>
            </div>
        <?php else: ?>
        <?php if(!$requests->isEmpty()): ?>
            <div class="mb-3 d-flex justify-content-end">
                <input type="text" id="requestSearch" class="form-control w-25" placeholder="Search requests...">
            </div>
        <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle text-center">
                    <thead class="table-light">
                        <tr>
                            <th></th>
                            <th>Date Filed</th>
                            <th>Unit Type</th>
                            <th>Room No</th>
                            <th>Request</th>
                            <th>Urgency</th>
                            <th>Supposed Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $urgencyClass = match($request->urgency) {
                                'high' => 'bg-danger text-white',
                                'mid' => 'bg-warning text-dark',
                                default => 'bg-success text-white',
                            };
                            $statusClass = match($request->status) {
                                'Pending' => 'bg-secondary text-white',
                                'Accepted' => 'bg-success text-white',
                                'Rejected' => 'bg-danger text-white',
                                default => 'bg-secondary',
                            };
                        ?>
                        <tr <?php if($request->urgency === 'high'): ?> class="table-danger" <?php endif; ?>>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($request->created_at)->format('D, M d, Y')); ?></td>
                            <td><?php echo e($request->unit_type ?? '-'); ?></td>
                            <td><?php echo e($request->room_no ?? '-'); ?></td>
                            <td><?php echo e(ucfirst($request->description)); ?></td>
                            <td><span class="badge <?php echo e($urgencyClass); ?>"><?php echo e(ucfirst($request->urgency)); ?></span></td>
                            <td><?php echo e(\Carbon\Carbon::parse($request->supposed_date)->format('D, M d, Y')); ?></td>
                            <td><span class="badge <?php echo e($statusClass); ?>"><?php echo e(ucfirst($request->status)); ?></span></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Create Request Modal -->
<div class="modal fade" id="createRequestModal" tabindex="-1" aria-labelledby="createRequestModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" action="<?php echo e(route('tenant.requests.store')); ?>" class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="createRequestModalLabel">New Maintenance Request</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Unit Type</label>
                    <input type="text" name="unit_type" class="form-control" value="<?php echo e(old('unit_type', $unitType)); ?>" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Room Number</label>
                    <input type="text" name="room_no" class="form-control" value="<?php echo e(old('room_no', $roomNo)); ?>" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Request Description</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Describe the issue..." required><?php echo e(old('description')); ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Urgency</label>
                    <select name="urgency" class="form-select" required>
                        <option value="" disabled selected>Select urgency</option>
                        <option value="low" <?php echo e(old('urgency') == 'low' ? 'selected' : ''); ?>>Low</option>
                        <option value="mid" <?php echo e(old('urgency') == 'mid' ? 'selected' : ''); ?>>Mid</option>
                        <option value="high" <?php echo e(old('urgency') == 'high' ? 'selected' : ''); ?>>High</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Supposed Date</label>
                    <input type="date" name="supposed_date" class="form-control" value="<?php echo e(old('supposed_date')); ?>" required>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-success">Submit Request</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('requestSearch');
    const table = document.querySelector('table tbody');
    const rows = table ? Array.from(table.querySelectorAll('tr')) : [];

    if(searchInput) {
        searchInput.addEventListener('input', function() {
            const term = this.value.toLowerCase();
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(term) ? '' : 'none';
            });
        });
    }

    // Optional: Simple column sorting
    document.querySelectorAll('table thead th').forEach((th, index) => {
        th.style.cursor = 'pointer';
        th.addEventListener('click', () => {
            const sortedRows = rows.sort((a, b) => {
                const aText = a.children[index].textContent.trim();
                const bText = b.children[index].textContent.trim();
                return aText.localeCompare(bText, undefined, { numeric: true });
            });
            sortedRows.forEach(row => table.appendChild(row));
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.tenantdashboardlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TenantNew\resources\views/tenant/request.blade.php ENDPATH**/ ?>