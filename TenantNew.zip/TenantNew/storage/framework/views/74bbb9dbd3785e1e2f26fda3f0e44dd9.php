Hey, and welcome here 😉

<br>
Funny Coder<?php /**PATH C:\laragon\www\TenantNew\resources\views/emails/welcome-email.blade.php ENDPATH**/ ?>