

<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="mb-4">Notifications</h3>

    <?php if($notifications->isEmpty()): ?>
        <div class="alert alert-info">
            You have no notifications at this time.
        </div>
    <?php else: ?>
        <div class="list-group">
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item list-group-item-action mb-2 <?php echo e($notification->is_read ? '' : 'fw-bold bg-light'); ?>">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1"><?php echo e($notification->title); ?></h5>
                        <small class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                    </div>
                    <p class="mb-1"><?php echo e($notification->message); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tenantdashboardlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TenantNew\resources\views/tenant/notifications.blade.php ENDPATH**/ ?>