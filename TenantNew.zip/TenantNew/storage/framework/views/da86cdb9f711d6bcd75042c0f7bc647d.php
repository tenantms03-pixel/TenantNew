

<?php $__env->startSection('title', 'Reports'); ?>
<?php $__env->startSection('page-title', 'Reports'); ?>

<?php
    use Illuminate\Support\Str;

    // Define themes for known report keys (key should match the route key you pass)
    $themeMap = [
        'payment-history' => [
            'bg'   => 'linear-gradient(135deg,#0d6efd,#5a9bf6)',
            'icon' => 'bi-cash-stack',
            'text' => '#ffffff'
        ],
        'active-tenants' => [
            'bg'   => 'linear-gradient(135deg,#198754,#48c78e)',
            'icon' => 'bi-people-fill',
            'text' => '#ffffff'
        ],
        'lease-summary' => [
            'bg'   => 'linear-gradient(135deg,#ffc107,#ffd95a)',
            'icon' => 'bi-house-fill',
            'text' => '#1f2d3d' // dark text for light bg
        ],
        'finance' => [
            'bg'   => 'linear-gradient(135deg,#dc3545,#f36c6c)',
            'icon' => 'bi-wallet2',
            'text' => '#ffffff'
        ],
        'maintenance-requests' => [
            'bg'   => 'linear-gradient(135deg,#20c997,#6fdcbf)',
            'icon' => 'bi-tools',
            'text' => '#ffffff'
        ],
        'application' => [
            'bg'   => 'linear-gradient(135deg,#6f42c1,#a678f1)',
            'icon' => 'bi-file-earmark-text',
            'text' => '#ffffff'
        ],
        // fallback theme
        'default' => [
            'bg'   => 'linear-gradient(135deg,#6c757d,#adb5bd)',
            'icon' => 'bi-bar-chart-line-fill',
            'text' => '#ffffff'
        ],
    ];
?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-4 fw-bold text-primary">📊 Reports Dashboard</h4>

    <div class="row g-4">
        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // make a slug-like key for mapping safety
                $slug = Str::slug($key);

                // choose theme (use slug if present otherwise default)
                $theme = $themeMap[$slug] ?? ($themeMap[$key] ?? $themeMap['default']);
            ?>

            <div class="col-md-4">
                <?php if(str_contains(strtolower($label), 'coming soon')): ?>
                    <div class="card shadow-sm border-0 h-100 bg-light text-muted text-center p-4">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center">
                            <div class="mb-3">
                                <i class="bi bi-clock-history display-4 text-secondary"></i>
                            </div>
                            <h5 class="card-title"><?php echo e($label); ?></h5>
                            <p class="small">🚧 This report is under development</p>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('manager.reports.show', $key)); ?>" class="text-decoration-none" aria-label="Open <?php echo e($label); ?> report">
                        <div class="card shadow-sm border-0 h-100 report-card" 
                             style="background: <?php echo e($theme['bg']); ?>; color: <?php echo e($theme['text']); ?>; border-radius: 12px;">
                            <div class="card-body d-flex flex-column justify-content-center align-items-center text-center p-4">
                                <div class="mb-3">
                                    <i class="<?php echo e($theme['icon']); ?> display-4" style="color: <?php echo e($theme['text']); ?>;"></i>
                                </div>
                                <h5 class="card-title fw-semibold" style="color: <?php echo e($theme['text']); ?>;"><?php echo e($label); ?></h5>
                                <p class="small" style="color: <?php echo e($theme['text']); ?>; opacity: .92;">Click to view detailed report</p>
                            </div>
                        </div>
                    </a>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    /* Shared hover + transition; color/bg are applied inline per card to avoid selector mismatch */
    .report-card {
        transition: transform 0.22s ease, box-shadow 0.22s ease;
    }
    .report-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 14px 40px rgba(0,0,0,0.12);
    }

    /* Small responsive tweak */
    @media (max-width: 576px) {
        .report-card .display-4 { font-size: 2.2rem; }
        .report-card .card-title { font-size: 1rem; }
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.managerdashboardlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TenantNew\resources\views/manager/reports/index.blade.php ENDPATH**/ ?>