

<?php $__env->startSection('title', 'Utilities Management'); ?>

<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
    /* Card styling */
    .card {
        border-radius: 16px;
        box-shadow: 0 6px 18px rgba(0,0,0,0.08);
        border: none;
    }
    .card-header {
        font-weight: 600;
        font-size: 1rem;
        border: none;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .card-header.bg-warning { 
        background: linear-gradient(135deg, #ffc107, #e0a800); 
        color: #212529; 
    }

    /* Table styling */
    .table thead th {
        text-align: center;
        vertical-align: middle;
        font-weight: 600;
        background: #fff3cd;
    }
    .table tbody tr:hover {
        background: #fff8e1;
        transition: 0.2s ease-in-out;
    }
    .table .text-end {
        text-align: right;
    }

    /* Buttons */
    .btn {
        border-radius: 8px;
        transition: 0.2s;
    }
    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .btn-sm {
        padding: 0.35rem 0.7rem;
        font-size: 0.85rem;
    }

    .btn-primary {
        background: linear-gradient(135deg, #ffc107, #e0a800);
        border: none;
        color: #212529;
    }
    .btn-primary:hover {
        background: linear-gradient(135deg, #e0a800, #ffc107);
        color: #212529;
    }

    /* Modal styling */
    .modal-content {
        border-radius: 14px;
        box-shadow: 0 8px 30px rgba(0,0,0,0.15);
        border: none;
    }
    .modal-header {
        background: linear-gradient(135deg, #ffc107, #e0a800);
        color: #212529;
        border-top-left-radius: 14px;
        border-top-right-radius: 14px;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .modal-footer {
        border-top: none;
    }
    .modal .btn-close {
        filter: invert(0);
    }

    /* Input styling for modal */
    .form-floating input {
        border-radius: 8px;
    }

    /* Alert container */
    #alertContainer .alert {
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    /* Responsive table scroll */
    .table-responsive {
        max-height: 450px;
        overflow-y: auto;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4 fw-bold text-warning">
        <i class="bi bi-lightning-charge-fill"></i> Utilities Management
    </h2>

    <!-- Utilities Overview Card -->
    <div class="card mb-4">
        <div class="card-header bg-warning">
            <i class="bi bi-list-check me-1"></i> Tenant Utilities Overview
        </div>
        <div class="card-body">
            <div id="alertContainer"></div>
            <div class="table-responsive">
                <table class="table table-hover align-middle text-center">
                    <thead>
                        <tr>
                            <th>Tenant Name</th>
                            <th>Room No</th>
                            <th>Utility Balance (₱)</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $leases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr id="lease-row-<?php echo e($lease->id); ?>">
                            <td><?php echo e($lease->tenant->name); ?></td>
                            <td><?php echo e($lease->room_no ?? 'N/A'); ?></td>
                            <td class="text-end">₱<?php echo e(number_format($lease->utility_balance, 2)); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-btn"
                                    data-id="<?php echo e($lease->id); ?>"
                                    data-name="<?php echo e($lease->tenant->name); ?>"
                                    data-balance="<?php echo e(number_format($lease->utility_balance, 2, '.', '')); ?>">
                                    <i class="bi bi-pencil-square me-1"></i> Update
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-muted">No tenant utility records found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Update Utility Modal -->
<div class="modal fade" id="editUtilityModal" tabindex="-1" aria-labelledby="editUtilityModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUtilityModalLabel">
                    <i class="bi bi-pencil-square"></i> Update Utility Balance
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editUtilityForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="leaseId">
                <div class="modal-body">
                    <div class="form-floating mb-3">
                        <input type="text" id="tenantName" class="form-control" placeholder="Tenant Name" readonly>
                        <label for="tenantName">Tenant Name</label>
                    </div>

                    <div class="form-floating mb-3">
                        <input type="text" id="utilityBalance" class="form-control text-end" placeholder="0.00" inputmode="decimal" required>
                        <label for="utilityBalance">Utility Balance (₱)</label>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-success">
                        <i class="bi bi-save me-1"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<script>
document.addEventListener("DOMContentLoaded", function () {
    const modal = new bootstrap.Modal(document.getElementById('editUtilityModal'));
    const editForm = document.getElementById('editUtilityForm');
    const tenantNameInput = document.getElementById('tenantName');
    const utilityBalanceInput = document.getElementById('utilityBalance');
    const leaseIdInput = document.getElementById('leaseId');
    const alertContainer = document.getElementById('alertContainer');

    // Open modal
    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', () => {
            leaseIdInput.value = button.dataset.id;
            tenantNameInput.value = button.dataset.name;
            utilityBalanceInput.value = parseFloat(button.dataset.balance).toLocaleString('en-PH', {minimumFractionDigits:2});
            modal.show();
        });
    });

    // Input formatting
    utilityBalanceInput.addEventListener('input', function () {
        const input = this;
        const cursor = input.selectionStart;
        const raw = input.value.replace(/,/g, '');
        const clean = raw.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');
        if (clean === '') { input.value = ''; return; }
        const [intPart, decPart] = clean.split('.');
        const formatted = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (decPart!==undefined?'.'+decPart:'');
        input.value = formatted;
        input.selectionEnd = cursor + (formatted.length - raw.length);
    });

    utilityBalanceInput.addEventListener('blur', function () {
        const val = parseFloat(this.value.replace(/,/g,''));
        if(!isNaN(val)){
            this.value = val.toLocaleString('en-PH', {minimumFractionDigits:2});
        }
    });

    // Submit update via AJAX
    editForm.addEventListener('submit', function(e){
        e.preventDefault();
        const leaseId = leaseIdInput.value;
        const formattedValue = parseFloat(utilityBalanceInput.value.replace(/,/g,''));
        const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

        if(isNaN(formattedValue)){
            alertContainer.innerHTML = `<div class="alert alert-danger">Invalid number entered.</div>`;
            return;
        }

        fetch(`/manager/utilities/${leaseId}`, {
            method: 'PUT',
            headers: {'X-CSRF-TOKEN': csrfToken,'Content-Type':'application/json'},
            body: JSON.stringify({utility_balance: formattedValue})
        })
        .then(r=>r.json())
        .then(data=>{
            if(data.success){
                document.querySelector(`#lease-row-${leaseId} .text-end`).textContent = '₱'+formattedValue.toLocaleString('en-PH',{minimumFractionDigits:2});
                modal.hide();
                alertContainer.innerHTML = `<div class="alert alert-success alert-dismissible fade show mt-3">${data.message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
            } else {
                alertContainer.innerHTML = `<div class="alert alert-danger alert-dismissible fade show mt-3">${data.message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
            }
        })
        .catch(err=>{
            console.error(err);
            alertContainer.innerHTML = `<div class="alert alert-danger alert-dismissible fade show mt-3">An error occurred while updating.</div>`;
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.managerdashboardlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TenantNew\resources\views/manager/utilities/index.blade.php ENDPATH**/ ?>