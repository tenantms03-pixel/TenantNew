

<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('page-title', $title); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">

    
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-secondary mb-0">
            <i class="bi bi-bar-chart-line me-2"></i> <?php echo e($title); ?>

        </h4>

        
        <a href="<?php echo e(route('manager.reports.viewReportPdf', array_merge(['report' => $report], request()->all()))); ?>" 
        target="_blank" 
        class="btn btn-danger btn-sm shadow-sm d-flex align-items-center">
            <i class="bi bi-file-earmark-pdf me-1"></i> Export / Preview PDF
        </a>
    </div>
    <hr>


    
    <?php if(in_array($report, ['active-tenants', 'pending-tenants', 'rejected-tenants', 'maintenance-requests', 'payment-history'])): ?>
        <div class="card shadow-sm mb-4 border-0">
            <div class="card-header bg-light fw-bold">
                <i class="bi bi-funnel-fill me-2 text-primary"></i> Filters
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('manager.reports.show', ['report' => $report])); ?>" class="row gy-2 gx-3 align-items-center">
                    
                    
                    <?php if($report === 'payment-history'): ?>
                        <div class="col-md-3">
                            <label for="payment_for" class="form-label fw-semibold">Purpose</label>
                            <select name="payment_for" id="payment_for" class="form-select" onchange="this.form.submit()">
                                <option value="">All</option>
                                <option value="rent" <?php echo e(request('payment_for') === 'rent' ? 'selected' : ''); ?>>Rent</option>
                                <option value="utilities" <?php echo e(request('payment_for') === 'utilities' ? 'selected' : ''); ?>>Utilities</option>
                                <option value="others" <?php echo e(request('payment_for') === 'others' ? 'selected' : ''); ?>>Others</option>
                            </select>
                        </div>

                    
                    <?php elseif($report === 'maintenance-requests'): ?>
                        <div class="col-md-3">
                            <label for="status" class="form-label fw-semibold">Status</label>
                            <select name="status" id="status" class="form-select" onchange="this.form.submit()">
                                <option value="">All</option>
                                <option value="Pending" <?php echo e(request('status') === 'Pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="In Progress" <?php echo e(request('status') === 'In Progress' ? 'selected' : ''); ?>>In Progress</option>
                                <option value="Completed" <?php echo e(request('status') === 'Completed' ? 'selected' : ''); ?>>Completed</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="urgency" class="form-label fw-semibold">Urgency</label>
                            <select name="urgency" id="urgency" class="form-select" onchange="this.form.submit()">
                                <option value="">All</option>
                                <option value="low" <?php echo e(request('urgency') === 'low' ? 'selected' : ''); ?>>Low</option>
                                <option value="mid" <?php echo e(request('urgency') === 'mid' ? 'selected' : ''); ?>>Mid</option>
                                <option value="high" <?php echo e(request('urgency') === 'high' ? 'selected' : ''); ?>>High</option>
                            </select>
                        </div>

                    
                    <?php elseif($report === 'active-tenants'): ?>
                        <div class="col-md-3">
                            <label for="unit_type" class="form-label fw-semibold">Unit Type</label>
                            <select name="unit_type" id="unit_type" class="form-select" onchange="this.form.submit()">
                                <option value="">All</option>
                                <?php $__currentLoopData = \App\Models\TenantApplication::select('unit_type')->distinct()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->unit_type); ?>" <?php echo e(request('unit_type') === $unit->unit_type ? 'selected' : ''); ?>>
                                        <?php echo e($unit->unit_type); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label for="employment_status" class="form-label fw-semibold">Employment Status</label>
                            <select name="employment_status" id="employment_status" class="form-select" onchange="this.form.submit()">
                                <option value="">All</option>
                                <?php $__currentLoopData = \App\Models\TenantApplication::select('employment_status')->distinct()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($emp->employment_status); ?>" <?php echo e(request('employment_status') === $emp->employment_status ? 'selected' : ''); ?>>
                                        <?php echo e($emp->employment_status); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body d-flex justify-content-between align-items-center">
            <div>
                <h5 class="fw-bold text-dark mb-1">
                    <?php if($report === 'payment-history'): ?>
                        <i class="bi bi-cash-coin text-success me-2"></i> Payment Summary
                    <?php elseif($report === 'maintenance-requests'): ?>
                        <i class="bi bi-tools text-warning me-2"></i> Maintenance Summary
                    <?php else: ?>
                        <i class="bi bi-list-ul text-secondary me-2"></i> Summary
                    <?php endif; ?>
                </h5>
                <p class="small text-muted mb-0">
                    <?php if($report === 'payment-history'): ?>
                        Showing: <strong><?php echo e($currentFilter ? ucfirst($currentFilter) : 'All Categories'); ?></strong>
                    <?php elseif($report === 'maintenance-requests'): ?>
                        Status: <strong><?php echo e(request('status') ?: 'All'); ?></strong> | 
                        Urgency: <strong><?php echo e(request('urgency') ?: 'All'); ?></strong>
                    <?php elseif($report === 'active-tenants'): ?>
                        Unit Type: <strong><?php echo e(request('unit_type') ?: 'All'); ?></strong> | 
                        Employment Status: <strong><?php echo e(request('employment_status') ?: 'All'); ?></strong>
                    <?php else: ?>
                        Total Records
                    <?php endif; ?>
                </p>
            </div>
            <div class="text-end">
                <?php if($report === 'payment-history'): ?>
                    <span class="small text-muted">Total Paid</span>
                    <div class="fs-4 fw-bold text-success">₱<?php echo e(number_format($total ?? 0, 2)); ?></div>
                <?php else: ?>
                    <span class="small text-muted">Total</span>
                    <div class="fs-4 fw-bold text-primary"><?php echo e($total ?? $data->total()); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped align-middle mb-0">
                    <thead class="table-secondary">
                        
                        <?php if($report === 'payment-history'): ?>
                            <tr>
                                <th>Tenant</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Purpose</th>
                                <th>Status</th>
                            </tr>
                        <?php elseif(in_array($report, ['active-tenants', 'pending-tenants', 'rejected-tenants'])): ?>
                            <tr>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Contact Number</th>
                                <th>Unit Type</th>
                                <th>Employment Status</th>
                                <th>Source of Income</th>
                                <th>Emergency Contact</th>
                                <th>Status</th>
                            </tr>
                        <?php elseif($report === 'lease-summary'): ?>
                            <tr>
                                <th>Tenant</th>
                                <th>Unit Type</th>
                                <th>Lease Start</th>
                                <th>Lease End</th>
                                <th>Lease Term</th>
                            </tr>
                        <?php elseif($report === 'maintenance-requests'): ?>
                            <tr>
                                <th>Tenant</th>
                                <th>Description</th>
                                <th>Urgency</th>
                                <th>Supposed Date</th>
                                <th>Status</th>
                            </tr>
                        <?php endif; ?>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <?php if($report === 'payment-history'): ?>
                                <tr>
                                    <td><?php echo e($item->tenant->name ?? 'N/A'); ?></td>
                                    <td><span class="fw-semibold">₱<?php echo e(number_format($item->pay_amount, 2)); ?></span></td>
                                    <td><?php echo e($item->pay_date?->format('M d, Y') ?? 'N/A'); ?></td>
                                    <td><?php echo e(ucfirst($item->payment_for)); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('manager.payments.updateStatus', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <select name="pay_status" class="form-select form-select-sm" onchange="this.form.submit()">
                                                <option value="Pending" <?php echo e($item->pay_status === 'Pending' ? 'selected' : ''); ?>>Pending</option>
                                                <option value="Accepted" <?php echo e($item->pay_status === 'Accepted' ? 'selected' : ''); ?>>Accepted</option>
                                            </select>
                                        </form>
                                    </td>
                                </tr>

                            
                            <?php elseif(in_array($report, ['active-tenants', 'pending-tenants', 'rejected-tenants'])): ?>
                                <?php $app = $item->tenantApplication; ?>
                                <tr>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($app->contact_number ?? 'N/A'); ?></td>
                                    <td><?php echo e($app->unit_type ?? 'N/A'); ?></td>
                                    <td><?php echo e($app->employment_status ?? 'N/A'); ?></td>
                                    <td><?php echo e($app->source_of_income ?? 'N/A'); ?></td>
                                    <td><?php echo e($app->emergency_name ?? 'N/A'); ?> <br><small class="text-muted"><?php echo e($app->emergency_number ?? ''); ?></small></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($item->status === 'approved' ? 'success' : ($item->status === 'pending' ? 'warning text-dark' : 'danger')); ?>">
                                            <?php echo e(ucfirst($item->status)); ?>

                                        </span>
                                    </td>
                                </tr>

                            
                            <?php elseif($report === 'lease-summary'): ?>
                            <?php $lease = $item->leases->first(); ?>
                            <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->tenantApplication->unit_type ?? 'N/A'); ?></td>
                                <td><?php echo e($lease?->lea_start_date ? \Carbon\Carbon::parse($lease->lea_start_date)->format('M d, Y') : 'N/A'); ?></td>
                                <td><?php echo e($lease?->lea_end_date ? \Carbon\Carbon::parse($lease->lea_end_date)->format('M d, Y') : 'N/A'); ?></td>
                                <td><?php echo e($lease?->lea_terms ?? 'N/A'); ?></td>
                            </tr>


                            
                            <?php elseif($report === 'maintenance-requests'): ?>
                                <tr>
                                    <td><?php echo e($item->tenant->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($item->description); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($item->urgency === 'high' ? 'danger' : ($item->urgency === 'mid' ? 'warning text-dark' : 'secondary')); ?>">
                                            <?php echo e(ucfirst($item->urgency)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->supposed_date)->format('M d, Y')); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('manager.requests.updateStatus', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                                <option value="Pending" <?php echo e($item->status === 'Pending' ? 'selected' : ''); ?>>Pending</option>
                                                <option value="In Progress" <?php echo e($item->status === 'In Progress' ? 'selected' : ''); ?>>In Progress</option>
                                                <option value="Completed" <?php echo e($item->status === 'Completed' ? 'selected' : ''); ?>>Completed</option>
                                            </select>
                                        </form>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%" class="text-center text-muted py-3">No records found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div class="card-footer bg-light d-flex justify-content-center">
            <?php echo e($data->appends(request()->query())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.managerdashboardlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TenantNew\resources\views/manager/reports/show.blade.php ENDPATH**/ ?>