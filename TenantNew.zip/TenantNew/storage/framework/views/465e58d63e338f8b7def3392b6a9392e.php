

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="mb-4">Property / Unit Applications</h3>

    <ul class="nav nav-tabs mb-3" id="applicationTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button">Pending</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="approved-tab" data-bs-toggle="tab" data-bs-target="#approved" type="button">Approved</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="rejected-tab" data-bs-toggle="tab" data-bs-target="#rejected" type="button">Rejected</button>
        </li>
    </ul>

    <div class="tab-content" id="applicationTabsContent">
        <!-- Pending Applications -->
        <div class="tab-pane fade show active" id="pending">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Tenant Name</th>
                        <th>Property</th>
                        <th>Unit Type</th>
                        <th>Room No</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pendingApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($app->tenant->name ?? 'N/A'); ?></td>
                            <td><?php echo e($app->property->name ?? 'N/A'); ?></td>
                            <td><?php echo e($app->unit_type ?? ($app->unit->type ?? 'N/A')); ?></td>
                            <td><?php echo e($app->room_no ?? ($app->unit->room_no ?? 'N/A')); ?></td>
                            <td><?php echo e($app->description); ?></td>
                            <td>
                                <form action="<?php echo e(route('manager.property-applications.approve', $app)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success btn-sm">Approve</button>
                                </form>
                                <form action="<?php echo e(route('manager.property-applications.reject', $app)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">No pending applications.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Approved Applications -->
        <div class="tab-pane fade" id="approved">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Tenant Name</th>
                        <th>Property</th>
                        <th>Unit Type</th>
                        <th>Room No</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $approvedApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($app->tenant->name ?? 'N/A'); ?></td>
                            <td><?php echo e($app->property->name ?? 'N/A'); ?></td>
                            <td><?php echo e($app->unit_type ?? ($app->unit->type ?? 'N/A')); ?></td>
                            <td><?php echo e($app->room_no ?? ($app->unit->room_no ?? 'N/A')); ?></td>
                            <td><?php echo e($app->description); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center">No approved applications.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Rejected Applications -->
        <div class="tab-pane fade" id="rejected">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Tenant Name</th>
                        <th>Property</th>
                        <th>Unit Type</th>
                        <th>Room No</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rejectedApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($app->tenant->name ?? 'N/A'); ?></td>
                            <td><?php echo e($app->property->name ?? 'N/A'); ?></td>
                            <td><?php echo e($app->unit_type ?? ($app->unit->type ?? 'N/A')); ?></td>
                            <td><?php echo e($app->room_no ?? ($app->unit->room_no ?? 'N/A')); ?></td>
                            <td><?php echo e($app->description); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center">No rejected applications.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.managerdashboardlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TenantNew\resources\views/manager/property-applications.blade.php ENDPATH**/ ?>