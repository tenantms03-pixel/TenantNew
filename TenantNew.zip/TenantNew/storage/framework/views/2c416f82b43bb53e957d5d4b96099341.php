<?php if($tenants->isEmpty()): ?>
    <div class="alert alert-warning text-center mt-4" role="alert">
        <i class="bi bi-exclamation-circle-fill"></i> No tenants found for this filter.
    </div>
<?php else: ?>
    <div class="row g-3">
        <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card tenant-card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-2">
                            <i class="bi bi-person-circle text-primary fs-3 me-2"></i>
                            <h5 class="card-title mb-0"><?php echo e($tenant->name); ?></h5>
                        </div>
                        <p class="mb-1"><i class="bi bi-envelope"></i> <?php echo e($tenant->email); ?></p>
                        <p class="mb-1"><i class="bi bi-telephone"></i> <?php echo e($tenant->phone ?? 'N/A'); ?></p>
                        <p class="mb-2"><i class="bi bi-house-door"></i> <?php echo e($tenant->unit ?? 'Not Assigned'); ?></p>

                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="badge 
                                <?php if($tenant->status == 'approved'): ?> bg-success
                                <?php elseif($tenant->status == 'pending'): ?> bg-warning text-dark
                                <?php elseif($tenant->status == 'rejected'): ?> bg-danger
                                <?php endif; ?>">
                                <?php echo e(ucfirst($tenant->status)); ?>

                            </span>

                            <a href="<?php echo e(route('manager.tenants', $tenant->id)); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-eye"></i> View
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\TenantNew\resources\views/partials/tenants_table.blade.php ENDPATH**/ ?>