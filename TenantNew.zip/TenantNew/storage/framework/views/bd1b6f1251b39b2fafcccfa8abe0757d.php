

<?php $__env->startSection('title', 'My Payments'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-6 mb-3">
        <div class="card shadow-sm border-0 rounded-4 text-white" style="background: linear-gradient(135deg, #ffb347, #ffcc33);">
            <div class="card-body">
                <h6 class="card-title fw-semibold">Unpaid Rent - <?php echo e(\Carbon\Carbon::now()->format('F Y')); ?></h6>
                <p class="card-text display-6 fw-bold">₱<?php echo e(number_format($unpaidRent, 2)); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-6 mb-3">
        <div class="card shadow-sm border-0 rounded-4 text-white" style="background: linear-gradient(135deg, #ff5f6d, #ffc371);">
            <div class="card-body">
                <h6 class="card-title fw-semibold">Unpaid Utilities - <?php echo e(\Carbon\Carbon::now()->format('F Y')); ?></h6>
                <p class="card-text display-6 fw-bold">₱<?php echo e(number_format($unpaidUtilities, 2)); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm rounded-4 border-0">
    <div class="card-header d-flex justify-content-between align-items-center bg-white border-bottom-0">
        <h5 class="mb-0 fw-bold">Payment History</h5>
        <button class="btn btn-primary btn-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#makePaymentModal">
            Make Payment
        </button>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success rounded-4"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger rounded-4"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php if($payments->isEmpty()): ?>
            <p class="text-muted">No payments found.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-borderless table-hover align-middle">
                    <thead class="table-light text-uppercase text-muted small">
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Payment For</th>
                            <th>Method</th>
                            <th>Amount</th>
                            <th>Account No</th>
                            <th>Status</th>
                            <th>Proof</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($payment->pay_date ?? $payment->created_at)->format('M d, Y')); ?></td>
                            <td><?php echo e($payment->payment_for ?? '-'); ?></td>
                            <td><?php echo e(ucfirst($payment->pay_method)); ?></td>
                            <td class="fw-semibold">₱<?php echo e(number_format($payment->pay_amount, 2)); ?></td>
                            <td><?php echo e($payment->account_no ?? '-'); ?></td>
                            <td>
                                <span class="badge rounded-pill bg-<?php echo e($payment->pay_status === 'Accepted' ? 'success' : 'warning text-dark'); ?>">
                                    <?php echo e($payment->pay_status); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($payment->proof): ?>
                                    <a href="<?php echo e(asset('storage/'.$payment->proof)); ?>" target="_blank" class="btn btn-outline-info btn-sm rounded-pill">View</a>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Make Payment Modal -->
<div class="modal fade" id="makePaymentModal" tabindex="-1" aria-labelledby="makePaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" action="<?php echo e(route('tenant.payments.store')); ?>" enctype="multipart/form-data" class="modal-content rounded-4 shadow-lg border-0 p-3">
            <?php echo csrf_field(); ?>
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold" id="makePaymentModalLabel">Make a Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body pt-0">
                <?php $user = auth()->user(); ?>

                <div class="form-floating mb-3">
                    <select name="payment_for" id="payment_for" class="form-select" required>
                        <?php if($user->deposit_amount > 0): ?>
                            <option value="Deposit" data-balance="<?php echo e($user->deposit_amount); ?>" selected>
                                Deposit (₱<?php echo e(number_format($user->deposit_amount, 2)); ?>)
                            </option>
                        <?php else: ?>
                            <?php if($user->rent_balance > 0): ?>
                                <option value="Rent" data-balance="<?php echo e($user->rent_balance); ?>">Rent (₱<?php echo e(number_format($user->rent_balance, 2)); ?>)</option>
                            <?php endif; ?>
                            <?php if($user->utility_balance > 0): ?>
                                <option value="Utilities" data-balance="<?php echo e($user->utility_balance); ?>">Utilities (₱<?php echo e(number_format($user->utility_balance, 2)); ?>)</option>
                            <?php endif; ?>
                        <?php endif; ?>
                        <option value="Other" data-balance="0">Other</option>
                    </select>
                    <label for="payment_for">Payment For</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="number" name="pay_amount" id="pay_amount" class="form-control" required>
                    <label for="pay_amount">Amount</label>
                </div>

                <div class="form-floating mb-3">
                    <select name="pay_method" id="payment_method" class="form-select" required>
                        <option value="">Select Method</option>
                        <option value="Cash">Cash</option>
                        <option value="GCash">GCash</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                    </select>
                    <label for="payment_method">Payment Method</label>
                </div>

                <div class="form-floating mb-3 d-none" id="accountNumberField">
                    <input type="text" name="account_no" class="form-control">
                    <label>Account / GCash Number</label>
                </div>

                <div class="mb-3">
                    <label class="form-label">Proof of Payment (Screenshot / Receipt)</label>
                    <input type="file" name="proof" class="form-control rounded-3" accept="image/*">
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary rounded-pill px-4">Submit Payment</button>
            </div>
        </form>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const paymentForSelect = document.getElementById('payment_for');
    const payAmountInput = document.getElementById('pay_amount');
    const paymentMethodSelect = document.getElementById('payment_method');
    const accountField = document.getElementById('accountNumberField');
    const modal = document.getElementById('makePaymentModal');

    // Disable Rent/Utilities if deposit exists
    const depositOption = paymentForSelect.querySelector('option[value="Deposit"]');
    if(depositOption) {
        Array.from(paymentForSelect.options).forEach(opt => {
            if(opt.value !== 'Deposit' && opt.value !== 'Other') {
                opt.disabled = true;
            }
        });
    }

    // Toggle account field
    paymentMethodSelect.addEventListener('change', () => {
        accountField.classList.toggle('d-none', !(paymentMethodSelect.value === 'GCash' || paymentMethodSelect.value === 'Bank Transfer'));
    });

    // Update amount based on selection
    function updateAmount() {
        const selectedOption = paymentForSelect.options[paymentForSelect.selectedIndex];
        const balance = parseFloat(selectedOption?.dataset.balance || 0);
        payAmountInput.value = balance > 0 ? balance : '';
        payAmountInput.min = balance > 0 ? 1 : 0;
    }
    paymentForSelect.addEventListener('change', updateAmount);

    // Default amount when modal opens
    modal.addEventListener('show.bs.modal', () => {
        let defaultOption = paymentForSelect.querySelector('option[value="Deposit"]') ||
                            paymentForSelect.querySelector('option[value="Rent"]') ||
                            paymentForSelect.querySelector('option[value="Utilities"]');
        if(defaultOption) {
            defaultOption.selected = true;
            updateAmount();
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tenantdashboardlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TenantNew\resources\views/tenant/payments.blade.php ENDPATH**/ ?>