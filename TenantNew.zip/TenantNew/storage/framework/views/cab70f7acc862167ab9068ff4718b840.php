

<?php $__env->startSection('title', 'Manage Units'); ?>

<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
    /* Card & Layout */
    .card { border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
    .card-header { font-weight: 600; font-size: 1.1rem; }

    /* Table Styling */
    .table thead th { text-align: center; vertical-align: middle; }
    .table-hover tbody tr:hover { background: #f9fafb; }
    .table td, .table th { vertical-align: middle; }

    /* Badges */
    .badge { font-size: 0.9rem; padding: 0.5em 1em; border-radius: 12px; }

    /* Buttons */
    .btn-sm { border-radius: 8px; }
    .btn-primary, .btn-warning, .btn-danger { box-shadow: 0 3px 10px rgba(0,0,0,0.1); }

    /* Modals */
    .modal-content { border-radius: 12px; box-shadow: 0 8px 25px rgba(0,0,0,0.2); }
    .modal-header { border-bottom: none; background: #0d6efd; color: #fff; border-top-left-radius: 12px; border-top-right-radius: 12px; }
    .modal-header.bg-danger { background: #dc3545; }
    .modal-footer { border-top: none; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4 fw-bold text-primary">🏠 Unit Management</h2>

    <!-- Add Unit Button -->
    <button type="button" class="btn btn-primary mb-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#createUnitModal">
        <i class="bi bi-plus-circle"></i> Add New Unit
    </button>

    <!-- Units Table -->
    <div class="card">
        <div class="card-header bg-dark text-white">All Units</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Room No</th>
                            <th>Room Price</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($unit->id); ?></td>
                            <td><span class="fw-semibold"><?php echo e($unit->type); ?></span></td>
                            <td><span class="fw-bold"><?php echo e($unit->room_no); ?></span></td>
                            <td><span class="text-success fw-semibold">₱<?php echo e(number_format($unit->room_price, 2)); ?></span></td>
                            <td>
                                <span class="badge <?php echo e($unit->status == 'vacant' ? 'bg-success' : 'bg-danger'); ?>">
                                    <?php echo e(ucfirst($unit->status)); ?>

                                </span>
                            </td>
                            <td>
                                <!-- Edit Button -->
                                <button type="button" class="btn btn-sm btn-warning me-1"
                                    data-bs-toggle="modal"
                                    data-bs-target="#editUnitModal<?php echo e($unit->id); ?>"
                                    title="Edit Unit">
                                    <i class="bi bi-pencil-square"></i>
                                </button>

                                <!-- Delete Button -->
                                <button type="button" class="btn btn-sm btn-danger"
                                    data-bs-toggle="modal"
                                    data-bs-target="#deleteUnitModal<?php echo e($unit->id); ?>"
                                    title="Delete Unit">
                                    <i class="bi bi-trash3-fill"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-muted text-center">No units available</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- CREATE modal -->
<div class="modal fade" id="createUnitModal" tabindex="-1" aria-labelledby="createUnitModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('manager.units.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Add Unit</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Type</label>
                        <select name="type" class="form-select" required>
                            <option value="">Select Type</option>
                            <?php $__currentLoopData = ['Studio','1-Bedroom','2-Bedroom', 'Commercial']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Room No</label>
                        <input type="text" name="room_no" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Room Price</label>
                        <input type="number" step="0.01" name="room_price" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="vacant">Vacant</option>
                            <option value="occupied">Occupied</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Unit</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- EDIT & DELETE modals -->
<?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Edit Modal -->
    <div class="modal fade" id="editUnitModal<?php echo e($unit->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?php echo e(route('manager.units.update', $unit->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Edit Unit</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Type</label>
                            <select name="type" class="form-select" required>
                                <option value="">Select Type</option>
                                <?php $__currentLoopData = ['Studio','1-Bedroom','2-Bedroom', 'Commercial']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>" <?php echo e($unit->type === $type ? 'selected' : ''); ?>><?php echo e($type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Room No</label>
                            <input type="text" name="room_no" class="form-control" value="<?php echo e($unit->room_no); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Room Price</label>
                            <input type="number" step="0.01" name="room_price" class="form-control" value="<?php echo e($unit->room_price); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="vacant" <?php echo e($unit->status == 'vacant' ? 'selected' : ''); ?>>Vacant</option>
                                <option value="occupied" <?php echo e($unit->status == 'occupied' ? 'selected' : ''); ?>>Occupied</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-warning">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Modal -->
    <div class="modal fade" id="deleteUnitModal<?php echo e($unit->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?php echo e(route('manager.units.destroy', $unit->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="modal-content">
                    <div class="modal-header bg-danger">
                        <h5 class="modal-title text-white"><i class="bi bi-trash3-fill"></i> Delete Unit</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p class="mb-0">Are you sure you want to delete this unit?</p>
                        <p class="fw-bold text-danger">Room No: <?php echo e($unit->room_no); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Yes, Delete</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var tooltipEls = [].slice.call(document.querySelectorAll('[title]'));
    tooltipEls.forEach(function (el) {
        new bootstrap.Tooltip(el);
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.managerdashboardlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TenantNew\resources\views/manager/unitsetup.blade.php ENDPATH**/ ?>