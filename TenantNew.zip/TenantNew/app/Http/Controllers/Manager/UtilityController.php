<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use App\Models\Lease;
use Illuminate\Http\Request;

class UtilityController extends Controller
{
    // Display list of tenants with utility balances
    public function index()
    {
        $leases = Lease::with('tenant')
            ->whereHas('tenant', function ($q) {
                $q->where('role', 'tenant')->where('status', 'approved');
            })
            ->get();

        return view('manager.utilities.index', compact('leases'));
    }

    // Update the utility balance
    public function updateUtilityBalance(Request $request, $id)
    {
        try {
            $request->validate([
                'utility_balance' => 'required|numeric|min:0',
            ]);

            // Find the Lease first to get the tenant (user)
            $lease = Lease::findOrFail($id);
            $user = $lease->tenant; // Get the User related to this lease

            if (!$user) {
                return response()->json(['success' => false, 'error' => 'Tenant not found'], 404);
            }

            // Update utility_balance on the User model
            $user->utility_balance = $request->utility_balance;
            $user->save();

            return response()->json([
                'success' => true,
                'new_balance' => $user->utility_balance,
                'message' => 'Utility balance updated successfully!'
            ]);
        } catch (\Exception $e) {
            \Log::error('UpdateUtilityBalance error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }


}
