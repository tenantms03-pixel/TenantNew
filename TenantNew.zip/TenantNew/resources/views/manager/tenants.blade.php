@extends('layouts.managerdashboardlayout')

@section('title', 'Manage Tenants')

@section('content')
<style>
    body {
        background-color: #f5f7fa;
        font-family: 'Inter', sans-serif;
    }

    .tenant-card {
        border-radius: 12px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        transition: transform 0.2s ease-in-out, box-shadow 0.2s;
        border: none;
    }

    .tenant-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 14px rgba(0,0,0,0.1);
    }

    .tenant-approved { background-color: #e9f7ef; }
    .tenant-pending { background-color: #fff8e1; }
    .tenant-rejected { background-color: #fdecea; }

    .filter-bar {
        margin-bottom: 25px;
    }

    .custom-select {
        appearance: none;
        border: 1.5px solid #dee2e6;
        border-radius: 12px;
        padding: 10px 44px 10px 16px;
        background-color: #ffffff;
        font-size: 0.95rem;
        color: #495057;
        font-weight: 500;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        transition: all 0.2s ease-in-out;
        width: 240px;
        cursor: pointer;
    }

    .custom-select:hover {
        border-color: #b2bec3;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08);
    }

    .custom-select:focus {
        outline: none;
        border-color: #0d6efd;
        box-shadow: 0 0 0 3px rgba(13,110,253,0.15);
    }

    .dropdown-icon {
        position: absolute;
        right: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: #6c757d;
        pointer-events: none;
        font-size: 1rem;
    }

    .status-badge {
        text-transform: capitalize;
        padding: 6px 12px;
        border-radius: 8px;
        font-size: 0.9rem;
        font-weight: 500;
    }

    .status-approved { background-color: #d4edda; color: #155724; }
    .status-pending { background-color: #fff3cd; color: #856404; }
    .status-rejected { background-color: #f8d7da; color: #721c24; }

    .btn-notify {
        background-color: #fff3cd;
        color: #856404;
        border: 1px solid #ffe58f;
        border-radius: 8px;
        transition: all 0.2s ease;
    }
    .btn-notify:hover {
        background-color: #ffecb5;
        color: #664d03;
        border-color: #ffd966;
    }

    /* Modal */
    .modal-content {
        border-radius: 14px;
        box-shadow: 0 8px 30px rgba(0,0,0,0.15);
        border: none;
    }
    .modal-header {
        background: linear-gradient(135deg, #0d6efd, #0a58ca);
        color: #fff;
        border-top-left-radius: 14px;
        border-top-right-radius: 14px;
    }
    .modal-footer {
        border-top: none;
    }
    .modal .btn-close {
        filter: invert(1);
    }
</style>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="fw-bold">Tenant Management</h3>

        <!-- Filter + Export -->
        <div class="d-flex align-items-center gap-3">
            <form method="GET" action="{{ route('manager.tenants') }}" class="filter-bar d-flex align-items-center gap-3 mb-0">
                <label for="filter" class="fw-semibold text-secondary mb-0">Filter by Status:</label>
                <div class="position-relative">
                    <select name="filter" id="filter" class="custom-select" onchange="this.form.submit()">
                        <option value="all" {{ $filter === 'all' ? 'selected' : '' }}>All Tenants</option>
                        <option value="pending" {{ $filter === 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="approved" {{ $filter === 'approved' ? 'selected' : '' }}>Approved</option>
                        <option value="rejected" {{ $filter === 'rejected' ? 'selected' : '' }}>Rejected</option>
                    </select>
                    <i class="bi bi-chevron-down dropdown-icon"></i>
                </div>
            </form>

            <!-- Export Button -->
            <a href="{{ route('manager.tenants.export', ['filter' => $filter]) }}"
               target="_blank"
               class="btn btn-danger btn-sm shadow-sm d-flex align-items-center">
                <i class="bi bi-file-earmark-pdf me-1"></i> Export / Preview PDF
            </a>
        </div>
    </div>

    <!-- Display Filtered Tenant Cards -->
    <div class="row g-3">
        @forelse($filteredTenants as $tenant)
            <div class="col-md-4">
                <div class="card tenant-card tenant-{{ $tenant->status }} p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="fw-semibold">{{ $tenant->name }}</h5>
                        <span class="status-badge status-{{ $tenant->status }}">
                            {{ ucfirst($tenant->status) }}
                        </span>
                    </div>

                    @if($tenant->status !== 'rejected')
                        <p class="mt-2 mb-1"><strong>Email:</strong> {{ $tenant->email }}</p>
                        <p class="mb-1"><strong>Rent Balance:</strong> ₱{{ number_format($tenant->rent_balance, 2) }}</p>
                        <p class="mb-3"><strong>Utility Balance:</strong> ₱{{ number_format($tenant->utility_balance, 2) }}</p>
                    @else
                        <p class="mt-3 mb-3 text-danger fw-semibold text-center">
                            Rejected Tenant (Reason: {{ $tenant->rejection_reason ?? 'N/A' }})
                        </p>
                    @endif

                    <div class="d-flex justify-content-between mt-2">
                        @if($tenant->tenantApplication && $tenant->tenantApplication->valid_id_path && $tenant->tenantApplication->id_picture_path)
                            <a href="{{ route('manager.tenants.viewIds', $tenant->id) }}" 
                               class="btn btn-outline-primary btn-sm" target="_blank">
                                <i class="bi bi-eye"></i> View IDs
                            </a>
                        @else
                            <button class="btn btn-outline-secondary btn-sm" disabled>
                                <i class="bi bi-eye-slash"></i> No IDs
                            </button>
                        @endif

                        @if($tenant->status === 'approved')
                            <form action="{{ route('manager.tenants.notify', $tenant->id) }}" method="POST" class="d-inline">
                                @csrf
                                <button type="submit" class="btn btn-notify btn-sm">
                                    <i class="bi bi-envelope-fill"></i> Notify
                                </button>
                            </form>
                        @elseif($tenant->status === 'pending')
                            <div class="d-flex gap-2">
                                <form action="{{ route('manager.tenant.approve', $tenant->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="bi bi-check-circle"></i> Approve
                                    </button>
                                </form>

                                <button type="button" class="btn btn-danger btn-sm"
                                    data-bs-toggle="modal"
                                    data-bs-target="#rejectTenantModal{{ $tenant->id }}">
                                    <i class="bi bi-x-circle"></i> Reject
                                </button>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        @empty
            <div class="text-center mt-4">
                <p class="text-muted">No tenants found for this filter.</p>
            </div>
        @endforelse
    </div>
</div>

<!-- Reject Modals -->
@foreach($filteredTenants as $tenant)
    @if($tenant->status === 'pending')
        <div class="modal fade" id="rejectTenantModal{{ $tenant->id }}" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <form method="POST" action="{{ route('manager.tenant.reject') }}">
                    @csrf
                    <input type="hidden" name="tenant_id" value="{{ $tenant->id }}">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="bi bi-x-circle"></i> Reject Tenant</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>Please provide a reason for rejecting <strong>{{ $tenant->name }}</strong>:</p>
                            <div class="mb-3">
                                <label class="form-label">Reason</label>
                                <select name="rejection_reason" class="form-select" required>
                                    <option value="">Select reason...</option>
                                    <option value="Incomplete application">Incomplete application</option>
                                    <option value="Failed background check">Failed background check</option>
                                    <option value="Credit score too low">Credit score too low</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger">Confirm Reject</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    @endif
@endforeach
@endsection
